#16426130/Ihsanul Amin
#02 Oktober 2026
#membagi sembako kepada warga dengan pembagian bulat dan modulo


s = int(input("Masukkan jumlah paket sembako:"))
w = int(input("Masukkan jumlah warga:"))
p = s//w
x = s%w

print(f"Setiap warga mendapat {p} paket sembako dan paket yang bersisa adalah sebanyak {x} paket")

